import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Facebook {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeDriver driver=new ChromeDriver(); 
		
		driver.get("https://en-gb.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.linkText("Create new account")).click();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		String title=driver.getTitle();
		System.out.println(title);
		driver.findElement(By.name("firstname")).sendKeys("Sowbaghya");
		driver.findElement(By.name("lastname")).sendKeys("Padmanabhan");
		//reg_email__
		driver.findElement(By.name("reg_email__")).sendKeys("Sowbaghyaxx.gmail.com");
		//password_step_input
		driver.findElement(By.id("password_step_input")).sendKeys("Nalan");
		WebElement day=driver.findElement(By.id("day"));
		Select dd=new Select(day);
		dd.selectByIndex(1);
		//month
		WebElement month=driver.findElement(By.id("month"));
		Select dm=new Select(month);
		dm.selectByValue("2");
		//year
		WebElement year=driver.findElement(By.id("year"));
		Select dy=new Select(year);
		dy.selectByVisibleText("2021");
		//u_2_4_W+
		driver.findElement(By.xpath("//input[@value='1']")).click();
		//driver.findElement(By.xpath("//div/input[@id='yesRadio']")).click();

		


	}

}
